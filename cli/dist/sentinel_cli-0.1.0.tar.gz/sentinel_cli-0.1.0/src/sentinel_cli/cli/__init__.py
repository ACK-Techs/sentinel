"""CLI surface for Sentinel."""
