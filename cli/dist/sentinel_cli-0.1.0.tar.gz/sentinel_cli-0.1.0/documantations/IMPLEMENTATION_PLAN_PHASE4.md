# Agentic CLI (Faz 4) — Uygulama Planı

Bu plan, `ROADMAP_PHASE3_5.md` ile uyumludur: **kendi observability ortamında** (ör. yerel veya kapalı ağda Grafana) çalışır; **Grafana’nın LLM bağlantılarını kolaylaştıran özellik** ile entegrasyon hedeflenir. **Çok kullanıcılı giriş / yönetici hesabı yok** — bu roadmap parçası değil.

**Önkoşul:** Faz 3 tamamlanmış veya en azından kurulum/doctor akışı stabil sayılır.

**Kök:** Yollar `sentinel-coming/cli/` altındadır; Grafana ve COS bileşenleri Faz 1 skill’leri ve mevcut teşhis dokümanlarıyla hizalanır.

---

## Faz 4.A — Hedef ve mimari çerçeve

| # | Adım | Başarı kriteri (checklist) | Hata / geri dönüş |
|---|------|---------------------------|-------------------|
| A.1 | **Grafana LLM “kolay bağlantı”** için resmi dokümantasyonu (sürümünü sabitle) oku; CLI’de hangi **env / URL / token** alanlarının anlamlı olduğunu tek sayfada özetle (ör. `documantations/` altında kısa not veya `LLM_PROVIDERS.md` bölümü). | Bağlantı için gereken parametreler listelenir; hayali API uydurulmaz. | API değişken → sürüm notu ve link. |
| A.2 | Sentinel’in rolü: **danışman CLI** — Grafana’ya doğrudan “panel kur” değil; **bağlantıyı doğrula**, kullanıcıya özet/sonraki adım öner (mevcut `run` / araç akışıyla uyumlu). | Bir “hikaye” cümlesi dokümanda yazılı. | Kapsam şişerse Faz 4’ü böl. |

---

## Faz 4.B — Entegrasyon yüzeyi (kod veya ince sarmalayıcı)

| # | Adım | Başarı kriteri (checklist) | Hata / geri dönüş |
|---|------|---------------------------|-------------------|
| B.1 | Yapılandırmada Grafana ile ilgili **opsiyonel** bölüm (ör. `base_url`, `api_key` env, `GF_*` ile çakışmayan isimler) — `sentinel.example.yaml` ve config modelleri ile uyumlu. | `doctor` bu ayarların varlığını/eksikliğini özetler (secret değer göstermez). | Zorunlu alan yok; hepsi opsiyonel. |
| B.2 | **Bağlantı testi:** Tek komut veya `doctor` altında alt kontrol — HTTP seviyesinde “erişilebilir + yetki kabuğu doğru” (detay Grafana sürümüne göre). | En az bir başarı ve bir bilinen hata (401/403/timeout) mesajı anlamlı. | Tam E2E panel testi şart değil (`ROADMAP`). |
| B.3 | İsteğe bağlı: Faz 1 **COS/Grafana teşhis** skill içeriğine **köprü** — CLI çıktısında ilgili skill adına referans (kopyalanabilir). | Kullanıcı Faz 1 dokümanına yönlendirilir. | Skill adı değişirse link metni güncellenir. |

---

## Faz 4.C — Gözlemlenebilirlik hizalaması

| # | Adım | Başarı kriteri (checklist) | Hata / geri dönüş |
|---|------|---------------------------|-------------------|
| C.1 | Prometheus/Loki/Alertmanager ile **ilişki** ihtiyacı varsa yalnız **teşhis sırası** olarak dokümante et (Faz 2.D skill’leriyle tutarlı). | “Veri yok” senaryosunda sonraki kontrol adımı yazılı. | — |
| C.2 | LLM önerilerinin **hallüsinasyon** riski: Grafana sürümüne özel adımlar için “doğrula” uyarısı. | Kritik işlem öncesi kullanıcı onayı veya salt-okun öneri net. | — |

---

## Faz 4.D — Test

| # | Adım | Başarı kriteri (checklist) | Hata / geri dönüş |
|---|------|---------------------------|-------------------|
| D.1 | Bağlantı mantığı **mock HTTP** ile test edilir (gerçek Grafana zorunlu değil). | CI ağından bağımsız yeşil test. | Entegrasyon testi manuel checklist ile tamamlanır. |
| D.2 | Varsa mevcut `pytest` yapısına uy; yeni dosyalar `tests/` altında. | `ruff` temiz. | — |

---

## Faz 4.E — Dokümantasyon

| # | Adım | Başarı kriteri (checklist) | Hata / geri dönüş |
|---|------|---------------------------|-------------------|
| E.1 | README’de Faz 4 özeti: Grafana LLM entegrasyonu nasıl açılır, `doctor` ne gösterir. | Faz 3 README akışı bozulmadan ek bölüm. | — |
| E.2 | `ROADMAP_PHASE3_5.md` ile çelişen ifade yok. | Tek gerçek kaynak roadmap. | — |

---

## Bilinçli dışarıda bırakılanlar

- Çok kiracılı / SSO / kurumsal kimlik — **yok**.
- Ürün telemetrisi — **yok** (Faz 3 ile aynı çizgi).
- Tam observability panel E2E otomasyonu — **yok**; bağlantı + teşhis yönlendirmesi yeterli.

---

## Dış kaynak

- `cli/documantations/ROADMAP_PHASE3_5.md`
- `cli/documantations/IMPLEMENTATION_PLAN_PHASE3.md`
- `cli/documantations/ARCHITECTURE_AGENTIC_CLI.md`
- Faz 1 / Faz 2: `agentic-troubleshoot-grafana` ve ilgili `agentic-cos-*` skill’leri

**Faz 4 kapanışı:** A–E tamamlandığında kısa teslim notu (isteğe bağlı `archive/` veya bu dosyaya tarih).
