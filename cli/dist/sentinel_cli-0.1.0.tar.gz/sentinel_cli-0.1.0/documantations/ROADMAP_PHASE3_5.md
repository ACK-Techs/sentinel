# Yol haritası — Faz 3–5

**Faz 2 (A–E)** `IMPLEMENTATION_PLAN_PHASE2.md` ile kapatıldı. **Faz 5** planı şimdilik yok; önce **Faz 3 ve 4**.

---

## Kapsam sınırı (önemli)

**Şu anki hedef:** Sistemi **yalnızca kendi kullanımın** için olgunlaştırmak — kendi makinede kur, dene, test et, gereksinimleri öğren.

- **Faz 3 ve 4** bu doğrultuda: iç kullanım, geliştirme ve doğrulama odaklı.  
- **Şirkete / müşteriye / dışarıya** yönelik paketleme, satış veya “kurumsal ürün” dilini **bu fazların doküman ve kodunda taşıma** niyeti yok; o aşama **sonra**, gerçek kullanımdan çıkan gereksinimlere göre çevrilecek.  
- **Telemetri (anonim istatistik vb.):** **Ürün ortaya çıktıktan sonra** eklenebilir; şimdilik **yok**, Faz 3’te de zorunlu değil.

---

## Özet fazlar

| Faz | Çalışma adı | Amaç (özet) |
|-----|-------------|-------------|
| **3** | CLI’yi kendi kullanımına “tam” sayılacak hale getirmek | Kendi makinede kurulum, paketleme, sertleştirme, tek okunabilir dokümantasyon — **hepsi bireysel/dev kullanımı için**. |
| **4** | Observability + Grafana LLM kolaylığı | Kendi stack’inde (ör. lokal Grafana) **Grafana’nın LLM bağlantısını kolaylaştıran özellik** ile entegrasyon; şimdilik **bağlantı testi** yeterli. |
| **5** | (Sonra) | İleride planlanır. |

---

## Onaylı kararlar

### Faz 3

1. **Dağıtım:** Öncelik **senin ortamında** tekrarlanabilir kurulum: wheel/sdist, `pip install -e`, doküman — **halka PyPI veya müşteri teslimi şart değil**; dışarıya özel kanal kararı **ürün aşamasında**.  
2. **Feature flag’ler:** Test için **hepsi açık kalabilir**; varsayılanları kilitleme işi **sonra**.  
3. **Telemetri:** **Şimdilik yok**; ürün netleştikten sonra düşünülür.

### Faz 4

4. **Entegrasyon:** Kendi observability kurulumunda Grafana; **Grafana’nın LLM bağlantıları için sunduğu kolaylık** hedeflenir.  
5. **Çok kullanıcılı giriş / yönetici hesabı:** **Şimdilik bu roadmap’in parçası değil**; observability ve ürün ihtiyacı netleşince ayrı tasarlanır. **Şu anki odak:** tek kullanıcı, kendi makine, öneri ve çözüm üreten CLI.  
6. **Test:** Şimdilik **bağlantı var mı** yeterli.

### Faz 5

7. **Ertelendi** — önce 3 ve 4.

---

## Dokümantasyon bakımı

- Faz 2 teslim notları: `archive/README.md`  
- Uygulama planları: [IMPLEMENTATION_PLAN_PHASE3.md](IMPLEMENTATION_PLAN_PHASE3.md), [IMPLEMENTATION_PLAN_PHASE4.md](IMPLEMENTATION_PLAN_PHASE4.md) (iç kullanım dilinde)  
- Faz 3’ü otomasyonla tek seferde yürütmek için: [CODEX_EXECUTION_PROMPT_PHASE3.md](CODEX_EXECUTION_PROMPT_PHASE3.md) — indeks: [PHASE3_SKILL_AND_DOC_INDEX.md](PHASE3_SKILL_AND_DOC_INDEX.md)

---

## Sonraki adım

1. Faz 3 görevlerini `IMPLEMENTATION_PLAN_PHASE3.md` üzerinden yürüt.  
2. Ardından Faz 4: `IMPLEMENTATION_PLAN_PHASE4.md`.  
3. Dışa dönük ürün ve telemetri — **ayrı faz / ayrı karar**.
